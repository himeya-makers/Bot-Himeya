global.mess = {
  wait: '⏳ Sedang diproses...',
  error: '🚫 Terjadi kesalahan, coba lagi nanti.',
  admin: 'Fitur ini hanya untuk admin grup!',
  default: 'Perintah Tidak dikenal?!',
    group: 'Fitur ini hanya bisa digunakan di dalam grup!',
  }
  
global.image = './db/img/pfp.png'

global.owner = ['6281243226450']
  
global.prefix = ['!', '.'];
  